MONEU 0.2.3 for Windows 10 and 11, 64-bit

Run moneu.exe.
It checks the computer, starts the node in the background and opens a
moneu> prompt. The commands are the same as moneu-cli on Linux,
without moneu-cli in front.

Data is kept in %APPDATA%\MONEU.

After the first start

Create a wallet, then generate its entropy file. Only then can you unlock
the wallet and create addresses.

    createwallet "your-passphrase"
    makenoise "your-passphrase"
    walletunlock "your-passphrase"
    getnewaddress

Copy the whole wallet folder including the entropy file to at least two
separate drives and encrypt them.
Losing the entropy file means losing access to the coins even with the
recovery words.

Do not create two different wallets on the same machine.

Checking the balance

    getwalletinfo
    listaddresses
    getbalance "address"

getwalletinfo shows the balance of the whole wallet.
listaddresses lists its addresses.
getbalance shows the balance of any single address, split into what can
be spent now and what is still waiting to mature.

Mining

    startmining "address" 2
    getmininginfo
    stopmining

Stopping

    stop      shuts the node down
    exit      closes the window, the node keeps running

Source code: https://github.com/natusor/MONEU
Website: https://moneu.cc
