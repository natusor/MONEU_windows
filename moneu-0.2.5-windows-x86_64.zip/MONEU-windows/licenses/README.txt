moneu-mi.exe has Qt 5.15.17 built in. Qt is used under the GNU LGPL version 3 copied in the qt folder.
The qt folder also keeps the licenses of the parts that Qt includes.
Qt source code: https://download.qt.io/archive/qt/5.15/5.15.17/submodules/
MONEU source code with the steps to build moneu-mi.exe with any other build of Qt: https://github.com/natusor/MONEU
